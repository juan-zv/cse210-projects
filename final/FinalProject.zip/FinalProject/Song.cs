using System;

public class Song:Album
{



public Song(string type, string name, string author, string invitedArtists, int length):base(type, name, author, invitedArtists, length){

}

}